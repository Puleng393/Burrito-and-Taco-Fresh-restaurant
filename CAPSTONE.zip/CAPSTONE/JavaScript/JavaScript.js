﻿
$("#thankyou").click(function () {
    alert("Thank you for liking our history.")
});
document.addEventListener("DOMContentLoaded", function () {
   
    const orderForm = document.getElementById('Orderform');
    const cancelButton = document.querySelector('button[type="submit"]:first-of-type');
    const placeOrderButton = document.querySelector('button[type="submit"]:last-of-type');

    orderForm.addEventListener('submit', function (event) {
       
        event.preventDefault();

      
        const firstName = orderForm.FirstName.value.trim();
        const surname = orderForm.Surname.value.trim();
        const phoneNumber = orderForm.PhoneNumber.value.trim();
        const emailAddress = orderForm.Address.value.trim();
        const cardHolder = orderForm['Card holder'].value.trim();
        const cardNumber = orderForm['card-number'].value.trim();
        const expirationDate = orderForm.expiration.value.trim();
        const cvv = orderForm.cvv.value.trim();

     
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneRegex = /^[0-9]{10}$/;
        const cardNumberRegex = /^[0-9]{16}$/;
        const cvvRegex = /^[0-9]{3,4}$/;

        
        if (!firstName || !surname || !phoneNumber || !emailAddress || !cardHolder || !cardNumber || !expirationDate || !cvv) {
            alert('Please fill in all required fields.');
            return;
        }

        
        if (!emailRegex.test(emailAddress)) {
            alert('Please enter a valid email address.');
            return;
        }

        
        if (!phoneRegex.test(phoneNumber)) {
            alert('Please enter a valid 10-digit phone number.');
            return;
        }

        
        if (!cardNumberRegex.test(cardNumber)) {
            alert('Please enter a valid 16-digit card number.');
            return;
        }

       
        if (!cvvRegex.test(cvv)) {
            alert('Please enter a valid CVV.');
            return;
        }

        
        alert('Order placed successfully!');
        orderForm.submit();
    });

    
    cancelButton.addEventListener('click', function (event) {
        event.preventDefault();
        if (confirm('Are you sure you want to cancel the order?')) {
            orderForm.reset();
        }
    });

    
    document.querySelector('input[name="Card"][value="mastercard"]').checked = true;
});

const prices = {
    burrito: 80,
    taco: 60,
    nachos: 90,
    salad: 70,
    special: {
        'All in One Special': 400,
        'Burrito and Taco combo': 155,
        'Burrito and Taco Special': 130,
        'Special Burrito Only': 320,
        'Special for 3': 400,
        'Special Tacos': 220
    },
    drink: {
        'Apple juice': 20,
        'Corolla beer': 50,
        'Ice cold Beer': 40,
        'Lemon juice': 20
    },
    kids: {
        'Kid Cheese Dilla': 120,
        'Kid Chicken Strips': 110,
        'Kid Taco Plate': 140
    }
};

function calculateTotal() {
    let total = 0;

    total += prices.burrito * document.getElementById('burritos').value;
    total += prices.taco * document.getElementById('Tacos').value;
    total += prices.nachos * document.getElementById('Nachos').value;
    total += prices.salad * document.getElementById('Salads').value;

    let specialValue = document.querySelector('select[name="Specials and Combos"]').value;
    if (specialValue !== 'None') {
        total += prices.special[specialValue] * document.getElementById('Specials and Combos').value;
    }

    let drinkValue = document.querySelector('select[name="Drinks"]').value;
    if (drinkValue !== 'None') {
        total += prices.drink[drinkValue] * document.getElementById('Drinks').value;
    }

    let kidsValue = document.querySelector('select[name="Kids Meal"]').value;
    if (kidsValue !== 'None') {
        total += prices.kids[kidsValue] * document.getElementById('Kids mean').value;
    }

    document.getElementById('totalAmount').textContent = `Total: R${total.toFixed(2)}`;
}

document.querySelectorAll('input[type="number"], select').forEach(element => {
    element.addEventListener('change', calculateTotal);
});


